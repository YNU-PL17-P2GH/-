<?xml version="1.0" encoding="UTF-8"?>
<tileset name="TileA5" tilewidth="16" tileheight="16" tilecount="512" columns="16">
 <image source="../tiled_picture/dm-vxmapsf/System/TileA5.png" width="256" height="512"/>
</tileset>
