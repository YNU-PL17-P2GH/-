<?xml version="1.0" encoding="UTF-8"?>
<tileset name="Had2Apps_SF_Robot_01" tilewidth="16" tileheight="16" tilecount="864" columns="36">
 <image source="../tiled_picture/SF_1_v1-1/characters/Had2Apps_SF_Robot_01.png" width="576" height="384"/>
</tileset>
