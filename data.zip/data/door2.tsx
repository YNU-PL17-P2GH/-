<?xml version="1.0" encoding="UTF-8"?>
<tileset name="door2" tilewidth="16" tileheight="16" tilecount="4864" columns="152">
 <image source="../map/doorMap.png" width="2432" height="512"/>
</tileset>
