<?xml version="1.0" encoding="UTF-8"?>
<tileset name="house" tilewidth="16" tileheight="16" tilecount="1147" columns="37">
 <image source="14.png" width="600" height="506"/>
</tileset>
