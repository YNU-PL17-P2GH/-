<?xml version="1.0" encoding="UTF-8"?>
<tileset name="horse" tilewidth="16" tileheight="16" tilecount="864" columns="36">
 <image source="moge-nature2-1.png" width="576" height="384"/>
</tileset>
