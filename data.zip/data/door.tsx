<?xml version="1.0" encoding="UTF-8"?>
<tileset name="door" tilewidth="16" tileheight="16" tilecount="576" columns="24">
 <image source="../sf-matome20051117/object/sf-ob-shelf01.png" width="384" height="384"/>
</tileset>
