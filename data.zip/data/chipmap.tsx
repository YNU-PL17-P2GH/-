<?xml version="1.0" encoding="UTF-8"?>
<tileset name="chipmap" tilewidth="16" tileheight="16" tilecount="7452" columns="162">
 <image source="../map/mapchipMap.png" width="2592" height="736"/>
</tileset>
