<?xml version="1.0" encoding="UTF-8"?>
<tileset name="1" tilewidth="16" tileheight="16" tilecount="1024" columns="32">
 <image source="5.png" width="512" height="512"/>
</tileset>
