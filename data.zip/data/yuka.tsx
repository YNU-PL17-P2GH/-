<?xml version="1.0" encoding="UTF-8"?>
<tileset name="yuka" tilewidth="16" tileheight="16" tilecount="96" columns="12">
 <image source="../sf-matome20051117/mapchip/sf-yuka01.png" width="192" height="128"/>
</tileset>
