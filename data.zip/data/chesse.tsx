<?xml version="1.0" encoding="UTF-8"?>
<tileset name="chesse" tilewidth="16" tileheight="16" tilecount="5125" columns="125">
 <image source="chesse.png" width="2000" height="667"/>
</tileset>
