<?xml version="1.0" encoding="UTF-8"?>
<tileset name="chesse" tilewidth="16" tileheight="16" tilecount="288" columns="18">
 <image source="chesse.png" width="288" height="256"/>
 <tile id="12">
  <objectgroup draworder="index">
   <object id="1" x="2" y="1" width="14" height="14"/>
  </objectgroup>
 </tile>
 <tile id="31">
  <animation>
   <frame tileid="3" duration="100"/>
   <frame tileid="21" duration="100"/>
   <frame tileid="22" duration="100"/>
  </animation>
 </tile>
 <tile id="143">
  <objectgroup draworder="index">
   <object id="1" x="15" y="14" width="14" height="12" rotation="180"/>
  </objectgroup>
 </tile>
</tileset>
