<?xml version="1.0" encoding="UTF-8"?>
<tileset name="lump" tilewidth="16" tileheight="16" tilecount="384" columns="24">
 <image source="lump.png" width="384" height="256"/>
</tileset>
