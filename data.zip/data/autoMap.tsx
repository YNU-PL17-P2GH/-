<?xml version="1.0" encoding="UTF-8"?>
<tileset name="autoMap" tilewidth="16" tileheight="16" tilecount="304" columns="38">
 <image source="../map/autoMap.png" width="608" height="128"/>
</tileset>
