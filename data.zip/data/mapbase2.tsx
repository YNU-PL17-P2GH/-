<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mapbase2" tilewidth="16" tileheight="16" tilecount="768" columns="32">
 <image source="e2leQJL.png" width="512" height="384"/>
</tileset>
