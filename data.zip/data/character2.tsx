<?xml version="1.0" encoding="UTF-8"?>
<tileset name="character2" tilewidth="16" tileheight="16" tilecount="48" columns="6">
 <image source="../gouseiki32x32_20160307/sample/sample03.png" width="96" height="128"/>
</tileset>
