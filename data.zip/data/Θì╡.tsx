<?xml version="1.0" encoding="UTF-8"?>
<tileset name="鍵" tilewidth="16" tileheight="16" tilecount="780" columns="26">
 <image source="鍵.jpg" width="427" height="480"/>
</tileset>
