<?xml version="1.0" encoding="UTF-8"?>
<tileset name="mapbase3" tilewidth="16" tileheight="16" tilecount="1464" columns="24">
 <image source="o0384098413285112984.png" width="384" height="984"/>
</tileset>
