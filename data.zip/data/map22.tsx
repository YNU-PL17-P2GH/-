<?xml version="1.0" encoding="UTF-8"?>
<tileset name="map22" tilewidth="16" tileheight="16" tilecount="2048" columns="64">
 <image source="monstermmorpg_map_firey_gulf_by_monstermmorpg-d4ahtqv.png" width="1024" height="512"/>
</tileset>
